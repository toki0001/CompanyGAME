
import React from 'react';
import { Difficulty } from '../types';

interface DifficultySelectorProps {
  selectedDifficulty: Difficulty;
  onDifficultyChange: (difficulty: Difficulty) => void;
}

const DifficultySelector: React.FC<DifficultySelectorProps> = ({ selectedDifficulty, onDifficultyChange }) => {
  const difficulties = [
    { value: Difficulty.Beginner, label: Difficulty.Beginner },
    { value: Difficulty.Intermediate, label: Difficulty.Intermediate },
    { value: Difficulty.Advanced, label: Difficulty.Advanced },
  ];

  return (
    <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
      {difficulties.map((difficulty) => (
        <div key={difficulty.value}>
          <label
            htmlFor={`difficulty-${difficulty.value}`}
            className={`
              block w-full p-4 rounded-lg cursor-pointer transition-all duration-150 ease-in-out
              text-center font-medium border-2
              ${selectedDifficulty === difficulty.value
                ? 'bg-yellow-400 border-yellow-500 text-purple-800 shadow-lg scale-105 ring-2 ring-yellow-300 ring-offset-2 ring-offset-white'
                : 'bg-purple-500 border-purple-400 text-white hover:bg-purple-600 hover:border-purple-500'
              }
            `}
          >
            <input
              type="radio"
              id={`difficulty-${difficulty.value}`}
              name="difficulty"
              value={difficulty.value}
              checked={selectedDifficulty === difficulty.value}
              onChange={() => onDifficultyChange(difficulty.value)}
              className="sr-only"
            />
            {difficulty.label}
          </label>
        </div>
      ))}
    </div>
  );
};

export default DifficultySelector;
