
import React from 'react';

interface IdeaDisplayProps {
  idea: string;
}

const IdeaDisplay: React.FC<IdeaDisplayProps> = ({ idea }) => {
  return (
    <p className="text-2xl md:text-3xl font-semibold text-center py-6 px-3 whitespace-pre-wrap break-words leading-relaxed">
      {idea}
    </p>
  );
};

export default IdeaDisplay;
