
import React from 'react';
import { Mode } from '../types';

interface ModeSelectorProps {
  selectedMode: Mode;
  onModeChange: (mode: Mode) => void;
}

const ModeSelector: React.FC<ModeSelectorProps> = ({ selectedMode, onModeChange }) => {
  const modes = [
    { value: Mode.ThreeWordBusiness, label: Mode.ThreeWordBusiness },
    { value: Mode.PitchBattle, label: Mode.PitchBattle },
  ];

  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
      {modes.map((mode) => (
        <div key={mode.value}>
          <label
            htmlFor={`mode-${mode.value}`}
            className={`
              block w-full p-4 rounded-lg cursor-pointer transition-all duration-150 ease-in-out
              text-center font-medium border-2
              ${selectedMode === mode.value
                ? 'bg-yellow-400 border-yellow-500 text-purple-800 shadow-lg scale-105 ring-2 ring-yellow-300 ring-offset-2 ring-offset-white'
                : 'bg-purple-500 border-purple-400 text-white hover:bg-purple-600 hover:border-purple-500'
              }
            `}
          >
            <input
              type="radio"
              id={`mode-${mode.value}`}
              name="mode"
              value={mode.value}
              checked={selectedMode === mode.value}
              onChange={() => onModeChange(mode.value)}
              className="sr-only" 
            />
            {mode.label}
          </label>
        </div>
      ))}
    </div>
  );
};

export default ModeSelector;
