
export enum Mode {
  ThreeWordBusiness = "3ワードビジネス",
  PitchBattle = "ピッチバトル",
}

export enum Difficulty {
  Beginner = "初級",
  Intermediate = "中級",
  Advanced = "上級",
}
